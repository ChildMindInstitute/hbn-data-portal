Filenames:

xxx_Video = Naturalistic Viewing Paradigm

Triggers are as following:
81 = Start of Video 1
101 = Stop of Video 1
82 = Start of Video 2
102 = Stop of Video 2
83 = Start of Video 3
103 = Stop of Video 3
84 = Start of Video 4
104 = Start of Video 4
….


block_perm:order of the movies
exclude:empty if all movies were shown
CD_START:marker for starting the video
CD_END:marker for end of the video
useEL:eye-tracker was recorded if 1
useEL_Calib:eye-tracker calibration was performed if 1
recordEEG: EEG was recorded if 1
