Resting paradigm:

The eye-tracking data for the resting paradigm are stored in the eye-tracking data files of the Sequence Learning paradigm (xxx_vis_learn Samples.txt)

There is no resting behavioral .mat file. 

Triggers are as following:

90: start of Resting EEG paradigm
20: eyes open start
30: eyes closed start
