Filenames:

xxx_SurrSupp_Blockx = Surround Suppression Paradigm

Triggers are as following:
93 = Surround Suppression Paradigm Block 1;
97 = Surround Suppression Paradigm Block 2;
4 = Stimulus ON
8 = Stimulus OFF

Bgcon:background condition (surround suppression ): 1 = there is background; 2 = there is no background
CNTcon: foreground contrast condition
StimCond: all Stimulus Condition
ITI: intertrial interval
CD_FIX_ON: marker for Stimulus ON
CD_TG: marker for Stimulus OFF
contrastsCNT: different foreground contrast conditions
trialsPerCond: how many trials per condition
trialdur: trial duration
CD_RESP: marker for start of paradigm
useEL: eye-tracker was recorded if 1
useEL_Calib: eye-tracker calibration was performed if 1
recordEEG: EEG was recorded if 1
